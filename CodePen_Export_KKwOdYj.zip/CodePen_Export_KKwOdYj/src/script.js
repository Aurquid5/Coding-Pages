coded by @vattgh3rn   const projectName='technical-docs-page';
localStorage.setItem('Techincal Docs Page');